package com.haruplanner.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val open = Intent(context, MainActivity::class.java)
        val content = PendingIntent.getActivity(context, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "haru_schedule")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("하루플랜 일정 알림")
            .setContentText(intent.getStringExtra("title") ?: "예정된 일정이 있어요")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(content)
            .build()
        try { NotificationManagerCompat.from(context).notify((intent.getStringExtra("id") ?: "0").hashCode(), notification) }
        catch (_: SecurityException) { }
    }
}
