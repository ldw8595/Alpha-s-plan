package com.haruplanner.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotificationPermission()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(PlannerBridge(this), "AndroidAlarm")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel("haru_schedule", "하루플랜 일정 알림", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "등록한 일정의 시작 알림"
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    class PlannerBridge(private val context: Context) {
        @JavascriptInterface fun schedule(id: String, title: String, date: String, time: String, offsetMinutes: Int) {
            try {
                val dt = LocalDateTime.parse("${date}T${time}:00").minusMinutes(offsetMinutes.toLong())
                val millis = dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                if (millis <= System.currentTimeMillis()) return
                val intent = Intent(context, AlarmReceiver::class.java).apply {
                    putExtra("title", title)
                    putExtra("id", id)
                }
                val pi = android.app.PendingIntent.getBroadcast(
                    context, id.hashCode() + offsetMinutes * 100000, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    val settings = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(settings)
                    return
                }
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            } catch (_: Exception) { }
        }

        @JavascriptInterface fun cancel(id: String) {
            for (offset in listOf(0, 5, 10)) {
                val intent = Intent(context, AlarmReceiver::class.java)
                val pi = android.app.PendingIntent.getBroadcast(
                    context, id.hashCode() + offset * 100000, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
            }
        }

        @JavascriptInterface fun saveAlarms(json: String) {
            context.getSharedPreferences("haru", Context.MODE_PRIVATE).edit().putString("alarms", json).apply()
        }
    }
}
