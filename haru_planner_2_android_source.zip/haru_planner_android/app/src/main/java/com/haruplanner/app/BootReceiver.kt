package com.haruplanner.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val raw = context.getSharedPreferences("haru", Context.MODE_PRIVATE).getString("alarms", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                MainActivity.PlannerBridge(context).schedule(
                    item.getString("id"), item.getString("title"),
                    item.getString("date"), item.getString("time"), item.optInt("offset", 0)
                )
            }
        } catch (_: Exception) { }
    }
}
